
//{{BLOCK(cuttingboard2)

//======================================================================
//
//	cuttingboard2, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ 184 tiles (t|f|p reduced) not compressed
//	+ regular map (flat), not compressed, 30x20 
//	Total size: 512 + 11776 + 1200 = 13488
//
//	Time-stamp: 2024-12-06, 14:52:35
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_CUTTINGBOARD2_H
#define GRIT_CUTTINGBOARD2_H

#define cuttingboard2TilesLen 11776
extern const unsigned short cuttingboard2Tiles[5888];

#define cuttingboard2MapLen 1200
extern const unsigned short cuttingboard2Map[600];

#define cuttingboard2PalLen 512
extern const unsigned short cuttingboard2Pal[256];

#endif // GRIT_CUTTINGBOARD2_H

//}}BLOCK(cuttingboard2)
