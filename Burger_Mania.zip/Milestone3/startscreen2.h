
//{{BLOCK(startscreen2)

//======================================================================
//
//	startscreen2, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ 203 tiles (t|f|p reduced) not compressed
//	+ regular map (flat), not compressed, 30x20 
//	Total size: 512 + 12992 + 1200 = 14704
//
//	Time-stamp: 2024-12-06, 04:21:04
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN2_H
#define GRIT_STARTSCREEN2_H

#define startscreen2TilesLen 12992
extern const unsigned short startscreen2Tiles[6496];

#define startscreen2MapLen 1200
extern const unsigned short startscreen2Map[600];

#define startscreen2PalLen 512
extern const unsigned short startscreen2Pal[256];

#endif // GRIT_STARTSCREEN2_H

//}}BLOCK(startscreen2)
