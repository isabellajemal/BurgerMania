
//{{BLOCK(lettuce)

//======================================================================
//
//	lettuce, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 245 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 7840 + 2048 = 10400
//
//	Time-stamp: 2024-11-27, 20:07:02
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LETTUCE_H
#define GRIT_LETTUCE_H

#define lettuceTilesLen 7840
extern const unsigned short lettuceTiles[3920];

#define lettuceMapLen 2048
extern const unsigned short lettuceMap[1024];

#define lettucePalLen 512
extern const unsigned short lettucePal[256];

#endif // GRIT_LETTUCE_H

//}}BLOCK(lettuce)
