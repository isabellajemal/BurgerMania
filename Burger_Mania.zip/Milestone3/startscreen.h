
//{{BLOCK(startscreen)

//======================================================================
//
//	startscreen, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 206 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 6592 + 2048 = 9152
//
//	Time-stamp: 2024-11-06, 14:56:45
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN_H
#define GRIT_STARTSCREEN_H

#define startscreenTilesLen 6592
extern const unsigned char startscreenTiles[6592];

#define startscreenMapLen 2048
extern const unsigned char startscreenMap[2048];

#define startscreenPalLen 512
extern const unsigned char startscreenPal[512];

#endif // GRIT_STARTSCREEN_H

//}}BLOCK(startscreen)
