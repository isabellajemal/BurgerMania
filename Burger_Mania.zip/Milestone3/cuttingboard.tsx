<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="cuttingboard" tilewidth="8" tileheight="8" tilecount="600" columns="30">
 <image source="../cuttingboard.png" width="240" height="160"/>
</tileset>
