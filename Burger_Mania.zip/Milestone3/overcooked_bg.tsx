<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="overcooked_bg" tilewidth="256" tileheight="256" tilecount="1" columns="1">
 <image source="overcooked_background.bmp" width="256" height="256"/>
</tileset>
