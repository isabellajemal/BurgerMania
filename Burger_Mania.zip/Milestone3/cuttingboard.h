
//{{BLOCK(cuttingboard)

//======================================================================
//
//	cuttingboard, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 274 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 8768 + 2048 = 11328
//
//	Time-stamp: 2024-11-19, 19:05:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_CUTTINGBOARD_H
#define GRIT_CUTTINGBOARD_H

#define cuttingboardTilesLen 8768
extern const unsigned short cuttingboardTiles[4384];

#define cuttingboardMapLen 2048
extern const unsigned short cuttingboardMap[1024];

#define cuttingboardPalLen 512
extern const unsigned short cuttingboardPal[256];

#endif // GRIT_CUTTINGBOARD_H

//}}BLOCK(cuttingboard)
