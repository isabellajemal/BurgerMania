
//{{BLOCK(meat)

//======================================================================
//
//	meat, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 439 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 14048 + 2048 = 16608
//
//	Time-stamp: 2024-11-27, 19:58:54
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MEAT_H
#define GRIT_MEAT_H

#define meatTilesLen 14048
extern const unsigned short meatTiles[7024];

#define meatMapLen 2048
extern const unsigned short meatMap[1024];

#define meatPalLen 512
extern const unsigned short meatPal[256];

#endif // GRIT_MEAT_H

//}}BLOCK(meat)
