
//{{BLOCK(servingplate)

//======================================================================
//
//	servingplate, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 240 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 7680 + 2048 = 10240
//
//	Time-stamp: 2024-11-27, 19:15:31
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SERVINGPLATE_H
#define GRIT_SERVINGPLATE_H

#define servingplateTilesLen 7680
extern const unsigned short servingplateTiles[3840];

#define servingplateMapLen 2048
extern const unsigned short servingplateMap[1024];

#define servingplatePalLen 512
extern const unsigned short servingplatePal[256];

#endif // GRIT_SERVINGPLATE_H

//}}BLOCK(servingplate)
