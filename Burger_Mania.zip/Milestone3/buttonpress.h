// buttonpress sound made by wav2c

extern const unsigned int buttonpress_sampleRate;
extern const unsigned int buttonpress_length;
extern const signed char buttonpress_data[];
