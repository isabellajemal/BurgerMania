#include "mode0.h"
#include "sprites.h"
#include "print.h"
#include "mode4.h"
#include "gba.h"
#include "print.h"
#include "startscreen.h"
#include "overcooked_background.h"
#include "chef.h"
#include "instructions.h"
#include "endscreen.h"
#include "cuttingboard.h"
#include "lettuce.h"
#include "meat.h"
#include "chef_2.h"
#include "analogSound.h"
#include "startscreen.h"
#include "digitalSound.h"
#include "cookingpan.h"
#include "startscreen.h"
#include "servingplate.h"
#include "startscreen.h"
#include "startfinal.h"
#include "cuttingboard2.h"


#include <stdlib.h>
#include "print.h"

#include "mode0.h"
#include "sprites.h"
#include "gba.h"

#include "play.h"
#include "digitalSound.h"
#include "buttons.h"
#include "gbaplayer.h"
#include "screen.h"

// TODO 2.3: Include buttonpress.h
#include "buttonpress.h"
#include "gamesong.h"
int seed;
// Include new header for serving plate image




void setupInterrupts();
void interruptHandler();



// Constants for enabling objects (sprites) and 1D mapping mode
#define OBJ_ENABLE 0x1000
#define OBJ_MAP_1D 0x0040
#define BG_PALETTE ((unsigned short *)0x5000000)




#define MAPWIDTH 400
#define MAPHEIGHT 456








// Game states
typedef enum {START, GAME, PAUSE, INSTRUCTIONS, CUTTINGBOARD, COOKINGPAN, SERVINGPLATE, WIN, LOSE} GameState;
int gameState = START;




typedef enum {DOWN, UP, LEFT, RIGHT} DIRECTION;








// Player structure
typedef struct {
  int x, y;
  int speed;
  int oamIndex;
  int currentFrame;
  int direction;
} Player;
SPRITE player;


typedef struct {
  int x, y;
  int currentFrame;
  int direction;  // Assuming directions for animation (e.g., left, right, up, down)
  int oamIndex;   // Index in the shadowOAM array
} Bread;
SPRITE bread;






// Define the Meat sprite structure
typedef struct {
  int x, y;
  int currentFrame;
  int direction;  // Assuming directions for animation
  int oamIndex;   // Index in the shadowOAM array
} Meat;
SPRITE meat;


typedef struct {
  int x, y;
  int currentFrame;
  int direction;  // Assuming directions for animation
  int oamIndex;   // Index in the shadowOAM array
} Lettuce;
SPRITE lettuce;

typedef struct {
  int x, y;
  int currentFrame;
  int direction;  // Assuming directions for animation (e.g., left, right, up, down)
  int oamIndex;   // Index in the shadowOAM array
} Bun;
SPRITE bun;






int hOff;
int vOff;


void initPlayer(){
   player.x = 70;
  player.y = 80;
  player.oamIndex = 0;
  player.currentFrame = 1;
  //player.direction = ;




  player.width = 16;
  player.height = 14;
  player.numFrames = 3;
  player.direction = DOWN;
  player.timeUntilNextFrame = 10;
  player.xVel = 1;
  player.yVel = 1;




}
 
void initMeat(){
   meat.x = 140;
  meat.y = 80;
  meat.oamIndex = 1;
   meat.currentFrame = 0;
  meat.direction = 0;




  meat.width = 20;
  meat.height = 12;
 meat.numFrames = 3;
  meat.direction = DOWN;
 meat.timeUntilNextFrame = 10;
  meat.xVel = 1;
  meat.yVel = 1;




}


void initBread(){
   bread.x = 200;
   bread.y = 100;
  bread.oamIndex = 2;
   bread.currentFrame = 0;
  bread.direction = 0;




  bread.width = 16;
  bread.height = 12;
 bread.numFrames = 3;
  bread.direction = DOWN;
 bread.timeUntilNextFrame = 10;
  bread.xVel = 1;
  bread.yVel = 1;




}
void initLettuce(){
   lettuce.x = 200;
   lettuce.y = 100;
  lettuce.oamIndex = 3;
   lettuce.currentFrame = 0;
  lettuce.direction = 0;




  lettuce.width = 16;
  lettuce.height = 12;
 lettuce.numFrames = 3;
  lettuce.direction = DOWN;
 lettuce.timeUntilNextFrame = 10;
  lettuce.xVel = 1;
  lettuce.yVel = 1;




}
void initBun(){
   bun.x = 200;
    bun.y = 100;
  bun.oamIndex = 4;
   bun.currentFrame = 0;
  bun.direction = 0;




  bun.width = 16;
  bun.height = 12;
 bun.numFrames = 3;
  bun.direction = DOWN;
 bun.timeUntilNextFrame = 10;
  bun.xVel = 1;
  bun.yVel = 1;




}
void interruptHandler() {

	REG_IME = 0;

    // TODO 1.1: Handle VBlank interrupts
    if (REG_IF & IRQ_VBLANK) {
        if (soundA.isPlaying) {
            soundA.vBlankCount++;
            if (soundA.vBlankCount >= soundA.durationInVBlanks) {
                if (soundA.looping) {
                    // loop sound
                    playSoundA(gamesong_data, gamesong_length, soundA.looping);
                } else {
                    soundA.isPlaying = 0;
                    REG_TM0CNT = TIMER_OFF;
                    DMA[1].ctrl = 0;
                }
            }
        }
        if (soundB.isPlaying) {
            soundB.vBlankCount++;
            if (soundB.vBlankCount >= soundB.durationInVBlanks) {
                if (soundB.looping) {
                    // loop sound
                    playSoundB(soundB.data, soundB.dataLength, soundB.looping);
                } else {
                    soundB.isPlaying = 0;
                    REG_TM1CNT = TIMER_OFF;
                    DMA[2].ctrl = 0;
                } 
            }
        }
    }
    REG_IF = REG_IF;
	REG_IME = 1;

} 

void setupInterrupts() {

	REG_IME = 0;

    // TODO 1.0: Set correct bits in interrupt enable register
    REG_IE = IRQ_VBLANK | IRQ_TIMER(3);

    REG_DISPSTAT = DISPSTAT_VBLANK_IRQ;
    REG_INTERRUPT = &interruptHandler;

	REG_IME = 1;

}








// Function prototypes
void initialize();
void initPlayer();
void initMeat();
void initBread();
void initLettuce();
void initBun();
void goToState(int state);
//void updatePlayer();
void drawInstructionsScreen();
void drawCuttingBoardScreen();
void animatePlayer();
void drawGame();
void drawStartScreen();
void drawPauseScreen();
void drawWinLoseScreen();
void drawGameScreen();
void drawEndScreen();
void drawServingPlateScreen();








OBJ_ATTR shadowOAM[128];




unsigned short buttons;
unsigned short oldButtons;




// Main game loop
int main() {
  initialize();




  while (1) {
      oldButtons = buttons;
      buttons = REG_BUTTONS;
      updatePlayer();
     waitForVBlank();
      playSoundA(gamesong_data, gamesong_length, 1); // Looping set to true




      if (BUTTON_PRESSED(BUTTON_A)) {
            playSoundA(gamesong_data, gamesong_length, 1);

        } 
// TODO 2.1: Play sound effect when B button is pressed
        if (BUTTON_PRESSED(BUTTON_B)) {
          playSoundB(gamesong_data, gamesong_length, 0);

 } 

        // TODO 2.2: Stop sounds completely when SELECT button is pressed
        if (BUTTON_PRESSED(BUTTON_SELECT)) {
            stopSounds();

        } 

        // TODO 2.3: Pause/unpause sounds when START button is pressed
        if (BUTTON_PRESSED(BUTTON_START)) {
            if (soundA.isPlaying) {
                pauseSounds();
            } else {
                unpauseSounds();
            }


        } 



      switch (gameState) {
          case START:
              drawStartScreen();
              if (BUTTON_PRESSED(BUTTON_START)) {
                  goToState(GAME);
              }
              break;
          case GAME:
              drawGameScreen();
              if (BUTTON_PRESSED(BUTTON_START)) {
                  goToState(WIN);
              }
              if (BUTTON_PRESSED(BUTTON_SELECT)) {
                  goToState(PAUSE);
              }
              break;
           case PAUSE:
              drawInstructionsScreen();
             // playAnalogSound(16);  // Play the "Shine" sound for the instructions
              if (BUTTON_PRESSED(BUTTON_SELECT)) {
                  goToState(GAME);
                   playAnalogSound(16); 
              }
              case INSTRUCTIONS:
              // playAnalogSound(16);
              drawInstructionsScreen();
              if (BUTTON_PRESSED(BUTTON_START)) {
                  goToState(START);
              }
              break;
               case CUTTINGBOARD:
              drawCuttingBoardScreen();
              if (BUTTON_PRESSED(BUTTON_DOWN)) {
                  goToState(GAME);  // Transition back to the game or another state
              }
              break;
          case COOKINGPAN:  // Handle cooking pan state
          drawCookingPanScreen();
           if (BUTTON_PRESSED(BUTTON_RIGHT)) {
                  goToState(GAME);  // Return to the game state
              }
              break;
          case SERVINGPLATE:
              drawServingPlateScreen(); // Display the serving plate screen
              break;
          case WIN: case LOSE:
              drawEndScreen();
              if (BUTTON_PRESSED(BUTTON_START)) {
                  initialize(); // Restart the game
                  goToState(START);
              }
              break;
      }
  }
  
  return 0;
}




// Initialize game elements
void initialize() {
 // REG_DISPCTL = MODE(0) | BG_ENABLE(2) | SPRITE_ENABLE;
   REG_DISPCTL = MODE(0) | BG_ENABLE(0) | BG_ENABLE(1) | BG_ENABLE(2) | SPRITE_ENABLE;
    REG_BG1HOFF = hOff; // Set horizontal offset for background 1
  REG_BG1VOFF = vOff; // Set vertical offset for background 1








  // Set up background control registers
 REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(8) | BG_SIZE_LARGE; // START  BG
 REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(9) | BG_SIZE_SMALL; // staz2rt?
 REG_BG2CNT = BG_CHARBLOCK(2) | BG_SCREENBLOCK(10) | BG_SIZE_LARGE; //



    setupSounds();
    setupInterrupts();

  buttons = REG_BUTTONS;
  oldButtons = 0;
  initPlayer();
  initMeat();
  initBread();
  initLettuce();
  initBun();




      initSound();








// Initializing hOff and vOff values
  hOff = 0;
  vOff = 0;




  goToState(START);
}




// Function to set game state and draw corresponding screen
void goToState(int state) {
  gameState = state;
  fillScreen4(0); // Clear screen with black color
  switch (state) {
      case START:
          drawStartScreen();
           playSoundA(gamesong_data, gamesong_length, 1);
          break;
      case GAME:
          drawGameScreen();
          break;
      case CUTTINGBOARD:
          drawCuttingBoardScreen();
          break;
      case COOKINGPAN:
          drawCookingPanScreen();
          break;
      case SERVINGPLATE: // New state for serving plate screen
          drawServingPlateScreen();
          break;
      case PAUSE:
          drawInstructionsScreen();
           playAnalogSound(16);
          break;
          case INSTRUCTIONS:  // Handle instructions screen
         drawInstructionsScreen();
          break;
      case WIN: case LOSE:
          drawEndScreen();
          break;
  }
}




//// Update player's movement and animation
void updatePlayer() {
  player.isAnimating = 0;
      player.currentFrame= soundA.isPlaying && DMA[1].ctrl & DMA_ON;

 // player.direction = -1;  // Reset direction to indicate no movement
  // Handle movement and set direction
  if (BUTTON_HELD(BUTTON_LEFT) || BUTTON_PRESSED(BUTTON_LEFT)) {
      // Check if not at the left edge
          player.x--;   // Move player left
          player.direction = LEFT;
         // player.isAnimating = 1;
        
     if (player.x < 70) {
          drawCuttingBoardScreen();
          return; // Stop further updates for this frame
      }
         if (player.y > 60 && player.x < 120) { // Ensure the player is at the center vertical position
          drawServingPlateScreen();
             // goToState(SERVINGPLATE);
              return;
          }




  }
  // Check if both Up + Left are pressed (increase speed in both directions)
   if (BUTTON_HELD(BUTTON_LEFT) && BUTTON_HELD(BUTTON_RSHOULDER)) {
       player.y= 200;
       player.x = 120;
        player.direction = LEFT; // Increase horizontal velocity (move faster to the left)
        // Increase vertical velocity (move faster up)
   }


   // Check if both Up + Right are pressed (increase speed in both directions) - cheat to get to cutting board
    if (BUTTON_HELD(BUTTON_RIGHT) && BUTTON_HELD(BUTTON_RSHOULDER)) {
       player.y= 100;
       player.x= 40;
        player.direction = RIGHT;  // Increase horizontal velocity (move faster to the right)// Increase vertical velocity (move faster up)
   }
   // Default velocity when no special combination is pressed
   else {
       if (BUTTON_HELD(BUTTON_LEFT) && BUTTON_HELD(BUTTON_RSHOULDER)) {
       player.y= 100;
       player.x = 120;
        player.direction = LEFT; //
       player.xVel = 1;   // Default horizontal velocity
       player.yVel = 1;   // Default vertical velocity
       }
   }


   if (BUTTON_HELD(BUTTON_RIGHT)) {
       if(player.x > 0){
           player.x++;
            player.direction = RIGHT;
      if (player.x < 70) {
          drawCuttingBoardScreen();
          return; // Stop further updates for this frame
      }
       if (player.x > 120 && player.y > 50){
          drawCookingPanScreen();
          return;
      }
      if (player.y > 50  && player.x < 120) { // Ensure the player is at the center vertical position
          drawServingPlateScreen();
             // goToState(SERVINGPLATE);
              return;
          }
      
       }
       //player.x=+20;
        player.direction = RIGHT;
       }


       if (BUTTON_HELD(BUTTON_LEFT)) {
           if(player.x > 0){
       // Check if not at the left edge
          player.x--;   // Move player left
          player.direction = LEFT;
          //player.isAnimating = 1;
      if (player.x < 70 && player.x > 0) {
          drawCuttingBoardScreen();
          return; // Stop further updates for this frame
      }
       if (player.x > 120 && player.y > 50){
          drawCookingPanScreen();
          return;
      }
      if (player.y > 50  && player.x < 120) { // Ensure the player is at the center vertical position
          drawServingPlateScreen();
             // goToState(SERVINGPLATE);
              return;
          }
           }
          player.direction = LEFT;
      
       }
     
 
 
  if (BUTTON_HELD(BUTTON_UP)) {
      if (player.y > 0) {  // Check if not at the top edge
          player.y--;   // Move player up
          player.direction = UP;
        //  player.isAnimating = 1;
      }
  }
  if (BUTTON_HELD(BUTTON_DOWN)) {
      if (player.y < SCREENHEIGHT - player.height) {  // Check if not at the bottom edge
          player.y++;   // Move player down
          player.direction = DOWN;
        //  player.isAnimating = 1;
      }
  }
  if (BUTTON_PRESSED(BUTTON_A)) {
      // Shift screen left when A is pressed
      vOff --;  // Adjust the value to shift left by the desired amount
  }
  if (BUTTON_PRESSED(BUTTON_B)) {
      // Shift screen right when B is pressed
      hOff ++;  // Adjust the value to shift right by the desired amount
  }
   // Check if player enters the "cutting board" area
  if (player.x >= 0 && player.x <= 50 && player.y <= 50) {
      goToState(CUTTINGBOARD);
       playSoundA(gamesong_data, gamesong_length, 1);
      return; // Stop further updates for this frame
  }
   // Check if player enters the "cooking pan" area (example position)
      if (player.x >= 160 && player.y > 50) {
          goToState(COOKINGPAN);
          return; // Stop further updates for this frame
      }
   if (player.x == 160 &&  player.y > 80) {
          goToState(SERVINGPLATE);
          return; // Stop further updates for this frame
      }
  // Animate the player if moving
  if (player.isAnimating) {
      player.timeUntilNextFrame--;
      if (player.timeUntilNextFrame == 0) {
          player.currentFrame++;
          if (player.currentFrame >= player.numFrames) {
             // player.currentFrame = 0;  // Loop back to the first frame
          player.currentFrame = (player.currentFrame + 1) % player.numFrames;
           player.timeUntilNextFrame = 10;
          }
          //player.timeUntilNextFrame = 10;
      }
  } else {
      // Reset animation frame if the player is idle
      player.currentFrame = 0;
      player.timeUntilNextFrame = 10;
  }




  // Adjust horizontal and vertical offsets to center the screen on the player
  if (player.x < SCREENWIDTH / 2) {
      hOff = 0;  // Don't scroll past the left edge
  } else if (player.x > MAPWIDTH - SCREENWIDTH / 2) {
      hOff = MAPWIDTH - SCREENWIDTH;  // Don't scroll past the right edge
  } else {
      hOff = player.x - SCREENWIDTH / 2;  // Center screen on the player
  }




  if (player.y < SCREENHEIGHT / 2) {
      vOff = 0;  // Don't scroll past the top edge
  } else if (player.y > MAPHEIGHT - SCREENHEIGHT / 2) {
      vOff = MAPHEIGHT - SCREENHEIGHT;  // Don't scroll past the bottom edge
  } else {
      vOff = player.y - SCREENHEIGHT / 2;  // Center screen on the player
  }
  }




// Draw the instructions screen (pause state)
void drawInstructionsScreen() {
  DMANow(3, instructionsTiles, &CHARBLOCK[0], instructionsTilesLen / 2);   // Tiles into CHARBLOCK[0]
  DMANow(3, instructionsMap, &SCREENBLOCK[8], instructionsMapLen / 2);      // Map into SCREENBLOCK[8]
  DMANow(3, instructionsPal, BG_PALETTE, instructionsPalLen / 2);           // Palettes into BG_PALETTE
}




// Draw the start screen
void drawStartScreen() {
 /// DMANow(3, startfinalTiles, &CHARBLOCK[0], startfinalTilesLen/ 2);
 ///DMANow(3, startfinalMap, &SCREENBLOCK[8], startfinalMapLen/ 2);
 //DMANow(3, startfinalPal, BG_PALETTE, startfinalPalLen/ 2);

   playSoundA(gamesong_data, gamesong_length, 1);

   DMANow(3, startscreenTiles, &CHARBLOCK[0], startscreenTilesLen / 2);
    DMANow(3, startscreenMap, &SCREENBLOCK[8], startscreenMapLen / 2);
    DMANow(3, startscreenPal, BG_PALETTE, startscreenPalLen / 2);
}




// Draw the game screen with the player sprite and background
void drawGameScreen() {
  DMANow(3, &overcooked_backgroundTiles, &CHARBLOCK[0], overcooked_backgroundTilesLen / 2);
  DMANow(3, &overcooked_backgroundMap, &SCREENBLOCK[8], overcooked_backgroundMapLen / 2);
  DMANow(3, &overcooked_backgroundPal, BG_PALETTE, overcooked_backgroundPalLen / 2);

 if (BUTTON_PRESSED(BUTTON_A)) {
            playSoundA(gamesong_data, gamesong_length, 1);

        } 


  DMANow(3, chef_2Tiles, &CHARBLOCK[4], chef_2TilesLen / 2);
  DMANow(3, chef_2Pal, SPRITE_PALETTE, chef_2PalLen / 2);




  // Update sprite attributes for the current animation frame
  int frameCol = player.currentFrame;  // Assuming 2 tiles per frame
  int frameRow = player.direction;    // Assuming 4 rows for directions

    player.currentFrame= soundA.isPlaying && DMA[1].ctrl & DMA_ON;

shadowOAM[player.oamIndex].attr0 = ATTR0_SQUARE| ATTR0_Y(player.y); // Set Y position
shadowOAM[player.oamIndex].attr1 = ATTR1_MEDIUM| ATTR1_X(player.x); // Set X position
shadowOAM[player.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(player.currentFrame *4, player.direction *4) ;


shadowOAM[meat.oamIndex].attr0 = ATTR0_WIDE| ATTR0_Y(player.y +13 ) | ATTR0_4BPP; // Set Y position
shadowOAM[meat.oamIndex].attr1 = ATTR1_MEDIUM| ATTR1_X(player.x + 30 ); // Set X position
shadowOAM[meat.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(6,16) |  ATTR2_PRIORITY(0);


shadowOAM[bread.oamIndex].attr0 = ATTR0_WIDE | ATTR0_Y(player.y + 30) | ATTR0_4BPP; // Set Y position
shadowOAM[bread.oamIndex].attr1 = ATTR1_MEDIUM | ATTR1_X(player.x + 30); // Set X position
shadowOAM[bread.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(11, 17) |  ATTR2_PRIORITY(0);


shadowOAM[lettuce.oamIndex].attr0 = ATTR0_SQUARE| ATTR0_Y(player.y -10)| ATTR0_4BPP; // Set Y position
shadowOAM[lettuce.oamIndex].attr1 = ATTR1_MEDIUM| ATTR1_X(player.x + 30); // Set X position
shadowOAM[lettuce.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(20, 8) |  ATTR2_PRIORITY(0);

shadowOAM[bun.oamIndex].attr0 = ATTR0_WIDE | ATTR0_Y(player.y -25) | ATTR0_4BPP; // Set Y position
shadowOAM[bun.oamIndex].attr1 = ATTR1_MEDIUM | ATTR1_X(player.x + 30); // Set X position
shadowOAM[bun.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(15, 16) |  ATTR2_PRIORITY(0);

if (BUTTON_PRESSED(BUTTON_A)){
  


shadowOAM[meat.oamIndex].attr0 = ATTR0_WIDE | ATTR0_REGULAR| ATTR0_Y(player.y +20); // Set Y position
shadowOAM[meat.oamIndex].attr1 = ATTR1_MEDIUM| ATTR1_X(player.x + 25); // Set X position
shadowOAM[meat.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(1,16) |  ATTR2_PRIORITY(0);




 // DMANow(3, shadowOAM, OAM, 512);


}






  DMANow(3, shadowOAM, OAM, 512);
 }
//Draw the cutting board screen
void drawCuttingBoardScreen() {
  DMANow(3, cuttingboardTiles, &CHARBLOCK[0], cuttingboardTilesLen / 2);
  DMANow(3, cuttingboardMap, &SCREENBLOCK[8], cuttingboardMapLen / 2);
  DMANow(3, cuttingboardPal, BG_PALETTE, cuttingboardPalLen / 2);


shadowOAM[lettuce.oamIndex].attr0 = ATTR0_SQUARE | ATTR0_REGULAR| ATTR0_Y(player.y - 10); // Set Y position
shadowOAM[lettuce.oamIndex].attr1 = ATTR1_LARGE| ATTR1_X(player.x + 25); // Set X position
shadowOAM[lettuce.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(20,13) |  ATTR2_PRIORITY(0);


if (BUTTON_PRESSED(BUTTON_A) || (BUTTON_PRESSED(BUTTON_LEFT) || player.x < 70)){
shadowOAM[lettuce.oamIndex].attr0 = ATTR0_SQUARE | ATTR0_REGULAR| ATTR0_Y(player.y - 10 ); // Set Y position
shadowOAM[lettuce.oamIndex].attr1 = ATTR1_LARGE| ATTR1_X(player.x + 25); // Set X position
shadowOAM[lettuce.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(20,13) |  ATTR2_PRIORITY(0);




 // DMANow(3, shadowOAM, OAM, 512);


}
if (BUTTON_HELD(BUTTON_A) || (player.x < 100 && player.y > 50)){
  


//shadowOAM[meat.oamIndex].attr0 = ATTR0_WIDE | ATTR0_REGULAR| ATTR0_Y(player.y + 20); // Set Y position
//shadowOAM[meat.oamIndex].attr1 = ATTR1_LARGE |  ATTR1_X(player.x + 25); // Set X position
//shadowOAM[meat.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(1,17) |  ATTR2_PRIORITY(0);




 // DMANow(3, shadowOAM, OAM, 512);


}




DMANow(3, shadowOAM, OAM, 512);




}
// Function to draw the cooking pan screen
void drawCookingPanScreen() {
  DMANow(3, cookingpanTiles, &CHARBLOCK[0], cookingpanTilesLen / 2);  // Tiles into CHARBLOCK[0]
  DMANow(3, cookingpanMap, &SCREENBLOCK[8], cookingpanMapLen / 2);     // Map into SCREENBLOCK[8]
  DMANow(3, cookingpanPal, BG_PALETTE, cookingpanPalLen / 2);          // Palettes into BG_PALETTE


shadowOAM[meat.oamIndex].attr0 = ATTR0_WIDE | ATTR0_REGULAR| ATTR0_Y(player.y +20); // Set Y position
shadowOAM[meat.oamIndex].attr1 = ATTR1_MEDIUM| ATTR1_X(player.x + 25); // Set X position
shadowOAM[meat.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(1,16) |  ATTR2_PRIORITY(0);





shadowOAM[lettuce.oamIndex].attr0 = ATTR0_SQUARE | ATTR0_REGULAR| ATTR0_Y(player.y - 7 ); // Set Y position
shadowOAM[lettuce.oamIndex].attr1 = ATTR1_LARGE| ATTR1_X(player.x + 20); // Set X position
shadowOAM[lettuce.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(20,13) |  ATTR2_PRIORITY(0);


if (BUTTON_PRESSED(BUTTON_A) || (BUTTON_PRESSED(BUTTON_B) || player.x > 100)){
shadowOAM[lettuce.oamIndex].attr0 = ATTR0_SQUARE | ATTR0_REGULAR| ATTR0_Y(player.y - 7 ); // Set Y position
shadowOAM[lettuce.oamIndex].attr1 = ATTR1_LARGE| ATTR1_X(player.x + 20); // Set X position
shadowOAM[lettuce.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(20,13) |  ATTR2_PRIORITY(0);




 // DMANow(3, shadowOAM, OAM, 512);


}




  DMANow(3, shadowOAM, OAM, 512);




}




// Draw the end screen
void drawEndScreen() {
  DMANow(3, endscreenTiles, &CHARBLOCK[0], endscreenTilesLen / 2);
  DMANow(3, endscreenMap, &SCREENBLOCK[8], endscreenMapLen / 2);
  DMANow(3, endscreenPal, BG_PALETTE, endscreenPalLen / 2);
}






void drawServingPlateScreen() {




  DMANow(3, servingplateTiles, &CHARBLOCK[0], servingplateTilesLen / 2);
  DMANow(3, servingplateMap, &SCREENBLOCK[8], servingplateMapLen / 2);
  DMANow(3, servingplatePal, BG_PALETTE, servingplatePalLen / 2);


shadowOAM[meat.oamIndex].attr0 = ATTR0_WIDE | ATTR0_REGULAR| ATTR0_Y(player.y +20); // Set Y position
shadowOAM[meat.oamIndex].attr1 = ATTR1_MEDIUM| ATTR1_X(player.x + 25); // Set X position
shadowOAM[meat.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(1,16) |  ATTR2_PRIORITY(0);


 




if (BUTTON_PRESSED(BUTTON_A) || (player.x < 100)) {



 

shadowOAM[lettuce.oamIndex].attr0 = ATTR0_SQUARE | ATTR0_REGULAR| ATTR0_Y(player.y - 7 ); // Set Y position
shadowOAM[lettuce.oamIndex].attr1 = ATTR1_LARGE| ATTR1_X(player.x + 20); // Set X position
shadowOAM[lettuce.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(20,13) |  ATTR2_PRIORITY(0);



}
DMANow(3, shadowOAM, OAM, 512);


}




// Draw the win or lose screen
void drawWinLoseScreen() {
  if (gameState == WIN) {
      // Display win message
  } else {
      // Display lose message
  }
}
