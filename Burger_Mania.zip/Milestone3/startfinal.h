
//{{BLOCK(startfinal)

//======================================================================
//
//	startfinal, 240x160@4, 
//	+ palette 256 entries, not compressed
//	+ 203 tiles (t|f|p reduced) not compressed
//	+ regular map (flat), not compressed, 30x20 
//	Total size: 512 + 6496 + 1200 = 8208
//
//	Time-stamp: 2024-12-06, 07:15:13
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTFINAL_H
#define GRIT_STARTFINAL_H

#define startfinalTilesLen 6496
extern const unsigned short startfinalTiles[3248];

#define startfinalMapLen 1200
extern const unsigned short startfinalMap[600];

#define startfinalPalLen 512
extern const unsigned short startfinalPal[256];

#endif // GRIT_STARTFINAL_H

//}}BLOCK(startfinal)
