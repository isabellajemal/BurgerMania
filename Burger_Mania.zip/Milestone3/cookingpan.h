
//{{BLOCK(cookingpan)

//======================================================================
//
//	cookingpan, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 228 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 7296 + 2048 = 9856
//
//	Time-stamp: 2024-11-20, 21:00:56
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COOKINGPAN_H
#define GRIT_COOKINGPAN_H

#define cookingpanTilesLen 7296
extern const unsigned short cookingpanTiles[3648];

#define cookingpanMapLen 2048
extern const unsigned short cookingpanMap[1024];

#define cookingpanPalLen 512
extern const unsigned short cookingpanPal[256];

#endif // GRIT_COOKINGPAN_H

//}}BLOCK(cookingpan)
